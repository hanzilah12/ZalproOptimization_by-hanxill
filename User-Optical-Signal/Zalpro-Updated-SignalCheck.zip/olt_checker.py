#!/usr/bin/env python3
"""
olt_checker.py - ONU optical signal checker for Zalpro (Huawei and VSOL GPON OLTs).

Given a subscriber username, this script:
  1. Finds the subscriber's MAC address in the RADIUS database.
  2. Queries all configured OLTs in parallel over SSH.
  3. Returns the optical power readings from the first OLT that reports the MAC.

Usage:
  python3 olt_checker.py --user <username> --json
  python3 olt_checker.py --mac <mac-address> --json
  python3 olt_checker.py --user <username> --olt <OLT_NAME> --json   (test one OLT only)
  Add --debug to print raw OLT output to stderr.

Configuration file: /etc/olt_checker.json
(override the path with the OLT_CHECKER_CONFIG environment variable)
"""

import argparse
import json
import logging
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import paramiko
import pymysql


# ----------------------------------------------------------------------------
# Global settings
# ----------------------------------------------------------------------------

logging.getLogger("paramiko").setLevel(logging.CRITICAL)

CONFIG_PATH = os.environ.get("OLT_CHECKER_CONFIG", "/etc/olt_checker.json")
DEBUG = False


# ----------------------------------------------------------------------------
# Helper functions
# ----------------------------------------------------------------------------

def fail(message, code=1):
    """Print a JSON error message and exit."""
    print(json.dumps({"status": "error", "message": message}))
    sys.exit(code)


def debug_log(label, text):
    """Print raw device output to stderr when --debug is enabled."""
    if DEBUG:
        sys.stderr.write(f"\n----- {label} -----\n{text}\n-----\n")


def load_config():
    """Load the JSON configuration file. Exit with an error if it cannot be read."""
    try:
        with open(CONFIG_PATH) as config_file:
            return json.load(config_file)
    except Exception as exc:
        fail(f"Config load failed ({CONFIG_PATH}): {exc}")


CONFIG = load_config()
DB_CONFIG = CONFIG["db"]
OLT_LIST = CONFIG["olts"]


def normalize_mac(raw_mac):
    """Return the MAC as 12 lowercase hex characters, or None if invalid.

    Accepts any common separator style, for example:
    2c:33:41:cf:25:58, 2c-33-41-cf-25-58, 2c33.41cf.2558
    """
    hex_only = re.sub(r"[^a-fA-F0-9]", "", str(raw_mac)).lower()
    return hex_only if len(hex_only) == 12 else None


def format_huawei_mac(hex_mac):
    """Convert 12 hex characters to Huawei format: xxxx-xxxx-xxxx."""
    return f"{hex_mac[0:4]}-{hex_mac[4:8]}-{hex_mac[8:12]}"


def format_vsol_mac(hex_mac):
    """Convert 12 hex characters to VSOL format: xxxx.xxxx.xxxx."""
    return f"{hex_mac[0:4]}.{hex_mac[4:8]}.{hex_mac[8:12]}"


# ----------------------------------------------------------------------------
# Database lookup
# ----------------------------------------------------------------------------

def get_mac_for_user(username):
    """Return the MAC address for a username.

    Lookup order:
      1. radacct      - current or most recent accounting session (most reliable)
      2. radpostauth  - most recent authentication log entry
      3. rm_users     - static MAC stored on the user record (table may not exist)

    Returns None if no MAC is found.
    """
    lookup_queries = [
        "SELECT callingstationid FROM radacct WHERE username = %s "
        "AND callingstationid IS NOT NULL AND callingstationid <> '' "
        "ORDER BY radacctid DESC LIMIT 1",

        "SELECT callingstationid FROM radpostauth WHERE username = %s "
        "AND callingstationid IS NOT NULL AND callingstationid <> '' "
        "ORDER BY id DESC LIMIT 1",

        "SELECT mac FROM rm_users WHERE username = %s "
        "AND mac IS NOT NULL AND mac <> '' AND mac <> '00:00:00:00:00:00' LIMIT 1",
    ]

    try:
        connection = pymysql.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            database=DB_CONFIG["name"],
            connect_timeout=5,
        )
    except Exception as exc:
        debug_log("database connection error", str(exc))
        return None

    try:
        with connection.cursor() as cursor:
            for query in lookup_queries:
                try:
                    cursor.execute(query, (username,))
                    row = cursor.fetchone()
                    if row and row[0]:
                        return row[0]
                except Exception:
                    # The table may not exist in this database; try the next source.
                    continue
        return None
    finally:
        connection.close()


# ----------------------------------------------------------------------------
# SSH helpers
# ----------------------------------------------------------------------------

def read_until_prompt(shell, timeout=15):
    """Read shell output until the CLI prompt appears or the timeout expires.

    A prompt is a last line ending with '>' or '#', for example:
      VSOL-Jandi>   VSOL-Jandi#   VSOL-Jandi(config)#   MA5683T(config)#

    Waiting for the prompt (instead of a fixed sleep) makes slow commands
    such as the Huawei MAC table lookup reliable.
    """
    output = ""
    deadline = time.time() + timeout

    while time.time() < deadline:
        if shell.recv_ready():
            output += shell.recv(65535).decode("utf-8", "ignore")
            lines = [line for line in output.splitlines() if line.strip()]
            if lines and re.search(r"[>#]\s*$", lines[-1]):
                # Allow any remaining bytes to arrive before returning.
                time.sleep(0.5)
                while shell.recv_ready():
                    output += shell.recv(65535).decode("utf-8", "ignore")
                break
        else:
            time.sleep(0.2)

    return output


def open_ssh_connection(olt):
    """Open an SSH connection to an OLT using password authentication."""
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        olt["ip"],
        username=olt["user"],
        password=olt["password"],
        timeout=8,
        look_for_keys=False,
        allow_agent=False,
    )
    return client


def extract_values(output, rx_pattern, tx_pattern, olt_rx_pattern):
    """Extract optical values from CLI output. Returns 'N/A' for missing values."""

    def first_match(pattern):
        match = re.search(pattern, output)
        return match.group(1) if match else "N/A"

    rx_ont = first_match(rx_pattern)
    tx_ont = first_match(tx_pattern)
    rx_olt = first_match(olt_rx_pattern)
    return rx_ont, tx_ont, rx_olt


def build_result(olt, mac, location, rx_ont, tx_ont, rx_olt):
    """Build the result dictionary returned to the caller."""
    return {
        "status": "success",
        "olt_name": olt["name"],
        "mac": mac,
        "location": location,
        "rx_ont": rx_ont,
        "tx_ont": tx_ont,
        "rx_olt": rx_olt,
        # Aliases used by the DMA Radius Manager frontend.
        "rx_power": rx_ont,
        "tx_power": tx_ont,
    }


# ----------------------------------------------------------------------------
# Huawei OLT query
# ----------------------------------------------------------------------------

def query_huawei_olt(olt, raw_mac):
    """Find the ONT by MAC on a Huawei OLT and read its optical power.

    Commands used:
      display mac-address all | include <mac>
      config
      interface gpon <frame>/<slot>
      display ont optical-info <port> <ont_id>
    """
    mac = format_huawei_mac(normalize_mac(raw_mac))
    client = None

    try:
        client = open_ssh_connection(olt)
        shell = client.invoke_shell()
        time.sleep(1)

        for command in ["enable", "undo smart", "scroll 512"]:
            shell.send(command + "\n")
            time.sleep(0.3)
        read_until_prompt(shell, timeout=2)

        # The full MAC table is slow on large OLTs, so allow up to 45 seconds.
        shell.send(f"display mac-address all | include {mac}\n")
        mac_output = read_until_prompt(shell, timeout=45)
        debug_log("Huawei MAC lookup", mac_output)

        match = re.search(
            r"gpon\s+[\w\-]+\s+\w+\s+(\d+)\s*/\s*(\d+)\s*/\s*(\d+)\s+(\d+)",
            mac_output,
        )
        if not match:
            return None

        frame, slot, port, ont_id = match.groups()

        shell.send("config\n")
        time.sleep(0.3)
        shell.send(f"interface gpon {frame}/{slot}\n")
        time.sleep(0.3)
        shell.send(f"display ont optical-info {port} {ont_id}\n")
        optical_output = read_until_prompt(shell, timeout=15)
        debug_log("Huawei optical info", optical_output)

        rx_ont, tx_ont, rx_olt = extract_values(
            optical_output,
            r"Rx optical power\(dBm\)\s*:\s*([\-\d\.]+)",
            r"Tx optical power\(dBm\)\s*:\s*([\-\d\.]+)",
            r"OLT Rx ONT optical power\(dBm\)\s*:\s*([\-\d\.]+)",
        )

        location = f"[{olt['name']}] Frame {frame}/Slot {slot}/Port {port} (ONT: {ont_id})"
        return build_result(olt, mac, location, rx_ont, tx_ont, rx_olt)

    except Exception as exc:
        debug_log("Huawei error", str(exc))
        return None

    finally:
        if client:
            client.close()


# ----------------------------------------------------------------------------
# VSOL OLT query
# ----------------------------------------------------------------------------

def query_vsol_olt(olt, raw_mac):
    """Find the ONT by MAC on a VSOL OLT and read its optical power.

    Commands used (in order):
      enable
      <enable password>
      configure terminal
      show mac address-table pon | include <mac>
      interface gpon <port>
      show onu <ont_id> optical_info
    """
    mac = format_vsol_mac(normalize_mac(raw_mac))
    client = None

    try:
        client = open_ssh_connection(olt)
        shell = client.invoke_shell()
        read_until_prompt(shell, timeout=3)  # Clear the login banner.

        shell.send("enable\n")
        read_until_prompt(shell, timeout=3)

        shell.send(olt.get("enable_password", olt["password"]) + "\n")
        read_until_prompt(shell, timeout=3)

        shell.send("configure terminal\n")
        read_until_prompt(shell, timeout=3)

        shell.send(f"show mac address-table pon | include {mac}\n")
        mac_output = read_until_prompt(shell, timeout=10)
        debug_log("VSOL MAC lookup", mac_output)

        # Example line: 2c33.41cf.2558  212  Dynamic  GPON0/2:1  ...
        match = re.search(r"GPON\s*(\d+/\d+)\s*:\s*(\d+)", mac_output, re.IGNORECASE)
        if not match:
            return None

        gpon_port, ont_id = match.groups()

        shell.send(f"interface gpon {gpon_port}\n")
        read_until_prompt(shell, timeout=3)

        shell.send(f"show onu {ont_id} optical_info\n")
        optical_output = read_until_prompt(shell, timeout=10)
        debug_log("VSOL optical info", optical_output)

        rx_ont, tx_ont, rx_olt = extract_values(
            optical_output,
            r"Rx optical level\(ONU\)\s*:\s*([\-\d\.]+)",
            r"Tx optical level\s*:\s*([\-\d\.]+)",
            r"Rx optical level\(OLT\)\s*:\s*([\-\d\.]+)",
        )

        location = f"[{olt['name']}] GPON {gpon_port} (ONT: {ont_id})"
        return build_result(olt, mac, location, rx_ont, tx_ont, rx_olt)

    except Exception as exc:
        debug_log("VSOL error", str(exc))
        return None

    finally:
        if client:
            client.close()


# ----------------------------------------------------------------------------
# Parallel search across all OLTs
# ----------------------------------------------------------------------------

def query_olt(olt, raw_mac):
    """Dispatch the query to the correct function based on OLT type."""
    try:
        if olt["type"] == "huawei":
            return query_huawei_olt(olt, raw_mac)
        if olt["type"] == "vsol":
            return query_vsol_olt(olt, raw_mac)
    except Exception as exc:
        debug_log(f"{olt.get('name')} unexpected error", str(exc))
    return None


def find_mac_on_olts(raw_mac):
    """Query all OLTs at the same time and return the first valid result.

    The remaining queries are abandoned once a result is found.
    """
    if not OLT_LIST:
        return None

    executor = ThreadPoolExecutor(max_workers=len(OLT_LIST))
    futures = [executor.submit(query_olt, olt, raw_mac) for olt in OLT_LIST]

    result = None
    for future in as_completed(futures):
        candidate = future.result()
        if candidate:
            result = candidate
            break

    executor.shutdown(wait=False)  # Do not wait for slower OLTs.
    return result


# ----------------------------------------------------------------------------
# Command-line entry point
# ----------------------------------------------------------------------------

def parse_arguments():
    parser = argparse.ArgumentParser(description="ONU optical signal checker for Zalpro")
    parser.add_argument("--user", help="Subscriber username (looked up in the database)")
    parser.add_argument("--mac", help="Subscriber MAC address (any common format)")
    parser.add_argument("--olt", help="Check only this OLT name (for testing)")
    parser.add_argument("--json", action="store_true", help="Print output as JSON")
    parser.add_argument("--debug", action="store_true", help="Print raw device output to stderr")
    return parser.parse_args()


def main():
    global DEBUG
    args = parse_arguments()
    DEBUG = args.debug

    if args.olt:
        OLT_LIST[:] = [olt for olt in OLT_LIST if olt["name"] == args.olt]
        if not OLT_LIST:
            fail(f"OLT '{args.olt}' was not found in the configuration")

    if args.user:
        raw_mac = get_mac_for_user(args.user)
        if not raw_mac:
            fail("User MAC not found in DB")
    elif args.mac:
        raw_mac = args.mac
    else:
        fail("Provide --user or --mac")

    if not normalize_mac(raw_mac):
        fail(f"Invalid MAC address: {raw_mac}")

    result = find_mac_on_olts(raw_mac)
    if not result:
        fail(f"MAC {raw_mac} not found on any configured OLT")

    if args.json:
        print(json.dumps(result))
    else:
        print("\n================ RESULT ================")
        print(f"Matched OLT   : {result['olt_name']}")
        print(f"Target MAC    : {result['mac']}")
        print(f"GPON Location : {result['location']}")
        print(f"ONU Rx Power  : {result['rx_ont']} dBm")
        print(f"ONU Tx Power  : {result['tx_ont']} dBm")
        print(f"OLT Rx Power  : {result['rx_olt']} dBm")
        print("========================================\n")


if __name__ == "__main__":
    main()
    sys.stdout.flush()
    # Exit immediately so that background SSH threads do not delay the response.
    os._exit(0)

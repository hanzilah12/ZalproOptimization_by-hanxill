# Zalpro OLT Signal Checker

This tool shows the live optical power of a subscriber's ONU (Rx and Tx in dBm) on the Zalpro user profile page. It supports **Huawei** and **VSOL** GPON OLTs.

---

## 1. How it works

1. The admin opens a subscriber's profile and clicks **Check Live Signal**.
2. The browser calls `get_olt_signal.php?user=<username>`.
3. The PHP script runs `olt_checker.py --user <username> --json`.
4. The Python script finds the subscriber's MAC address in the RADIUS database.
5. The script queries **all OLTs at the same time** over SSH.
6. The first OLT that reports the MAC returns its optical readings.
7. The result is returned as JSON and shown on the page.

The MAC lookup order in the database is:

| Order | Table | Column | Reason |
|-------|-------|--------|--------|
| 1 | `radacct` | `callingstationid` | Current or latest session. Most reliable. |
| 2 | `radpostauth` | `callingstationid` | Latest authentication log entry. |
| 3 | `rm_users` | `mac` | Static MAC stored on the user record (only if the table exists). |

---

## 2. Files in this package

| File | Install location | Purpose |
|------|------------------|---------|
| `olt_checker.py` | `/opt/olt_checker.py` | Python backend: database lookup, SSH to OLTs, parsing |
| `olt_checker.json.example` | `/etc/olt_checker.json` (after editing) | Configuration: database and OLT credentials |
| `get_olt_signal.php` | `/var/www/html/get_olt_signal.php` | PHP bridge between the browser and Python |
| `README.md` | Keep for reference | This guide |

The frontend widget (`olt-signal.php`) does not need any change. It already calls `get_olt_signal.php`.

---

## 3. Prerequisites

Run these on the Zalpro server:

```bash
apt update
apt install -y python3 python3-pip
pip3 install paramiko pymysql
```

If the installation fails with build errors:

```bash
apt install -y build-essential libssl-dev libffi-dev python3-dev
```

Check that both libraries load:

```bash
python3 -c "import paramiko, pymysql; print('OK')"
```

---

## 4. Installation

### Step 1: Create the configuration file

```bash
cp olt_checker.json.example /etc/olt_checker.json
nano /etc/olt_checker.json
```

Replace every `CHANGE_ME` value:

| Field | Meaning |
|-------|---------|
| `db.user` / `db.password` | MySQL user and password for the Zalpro database |
| `db.name` | Database that contains `radacct` and `radpostauth` (usually `zalpro`) |
| `olts[].name` | Any label you like. It appears in the result. |
| `olts[].type` | `huawei` or `vsol` |
| `olts[].ip` | OLT management IP address |
| `olts[].user` / `olts[].password` | SSH login details for the OLT |
| `olts[].enable_password` | Enable-mode password (VSOL). Optional for Huawei. |

**Add or remove OLTs** by copying or deleting a whole `{ ... }` block inside `olts`. Keep commas correct between blocks. The last block must not have a trailing comma.

Validate the JSON after editing:

```bash
python3 -m json.tool /etc/olt_checker.json > /dev/null && echo "JSON OK"
```

Restrict access, since this file contains passwords:

```bash
chown root:www-data /etc/olt_checker.json      # CentOS: root:apache
chmod 640 /etc/olt_checker.json
```

### Step 2: Install the Python script

```bash
nano /opt/olt_checker.py
```

Paste the contents of `olt_checker.py`, save, then:

```bash
chown root:www-data /opt/olt_checker.py        # CentOS: root:apache
chmod 750 /opt/olt_checker.py
```

### Step 3: Install the PHP bridge

```bash
nano /var/www/html/get_olt_signal.php
```

Paste the contents of `get_olt_signal.php`, save, then confirm that the web server can read it:

```bash
ls -l /var/www/html/get_olt_signal.php
```

### Step 4: Frontend

No change is needed in `olt-signal.php`. Confirm that it is still included on the subscriber profile page.

---

## 5. Testing

Run the tests in this order. Stop at the first failure and fix it before continuing.

**Test 1: Database MAC lookup**

```bash
mysql -u root -p -D zalpro -e "SELECT username, callingstationid FROM radacct WHERE username='USERNAME' LIMIT 1;"
```

You should see a MAC address in `callingstationid`.

**Test 2: One OLT only (fastest way to find a connection problem)**

```bash
python3 /opt/olt_checker.py --user USERNAME --olt OLT_NAME --json --debug
```

`OLT_NAME` must match the `name` field in the configuration exactly.

**Test 3: All OLTs (normal operation)**

```bash
time python3 /opt/olt_checker.py --user USERNAME --json
```

**Test 4: Web bridge**

```bash
curl "http://localhost/get_olt_signal.php?user=USERNAME"
```

**Test 5: Browser**

Open the subscriber profile page and click **Check Live Signal**.

---

## 6. Command reference

| Command | Purpose |
|---------|---------|
| `python3 /opt/olt_checker.py --user <name> --json` | Normal lookup by username |
| `python3 /opt/olt_checker.py --mac <mac> --json` | Lookup by MAC address (any format) |
| `python3 /opt/olt_checker.py --user <name> --olt <OLT_NAME> --json` | Check one OLT only |
| `python3 /opt/olt_checker.py --user <name> --json --debug` | Show raw OLT output on stderr |

Accepted MAC formats: `2c:33:41:cf:25:58`, `2c-33-41-cf-25-58`, `2c33.41cf.2558`, `2c3341cf2558`.

---

## 7. Troubleshooting

| Symptom | Likely cause | What to do |
|---------|--------------|------------|
| `Config load failed` | Invalid JSON or wrong file path | Run the JSON validation command in Step 1 |
| `User MAC not found in DB` | No session or auth record for the user | Run Test 1. Check the username spelling. |
| `not found on any configured OLT` | ONU offline, MAC not learned on the OLT, or wrong OLT | Run Test 2 for each OLT with `--debug` |
| Test 2 shows `timed out` | Zalpro server cannot reach that OLT over SSH | See section 8 (routing and reachability) |
| Test 2 shows the MAC but no optical values | Output format differs from the regex | Send the `--debug` output so the regex can be updated |
| `No valid response from OLT checker` | Python crashed or printed invalid output | Run the command in the terminal without `--json` |
| Button is slow | One OLT is slow or unreachable | Check that OLT with Test 2 |
| Permission denied | Web server user cannot read the files | Check the `chown` and `chmod` values in section 4 |

---

## 8. Network reachability (important)

The OLT may be reachable from your own PC but **not** from the Zalpro server, because of routing or firewall rules. Check from the Zalpro server:

```bash
ping -c 3 <OLT_IP>
ip route get <OLT_IP>
nc -vz -w 5 <OLT_IP> 22
ssh -v admin@<OLT_IP>
```

Meaning of the results:

- **Ping works, SSH times out:** a firewall or ACL blocks port 22 from this server, or the OLT limits SSH to certain source IPs.
- **`ip route get` shows an unexpected gateway:** the server has the wrong route. Fix the routing.
- **Ping fails:** basic routing or the OLT IP is wrong.

If the OLT allows login only from certain source IPs, add the Zalpro server IP to the OLT's allowed list.

---

## 9. Security notes

- Never commit `/etc/olt_checker.json` to Git or share it.
- Keep the username validation in `get_olt_signal.php`. It protects the shell command from injection.
- Use a read-only database account for the checker if possible. It only needs `SELECT` on `radacct`, `radpostauth`, and `rm_users`.
- Change any password that has been shared in chat, email, or old files.
- Limit access to the OLTs' SSH service to the management network only.

---

## 10. Deployment checklist

- [ ] Python packages installed (`paramiko`, `pymysql`)
- [ ] `/etc/olt_checker.json` created, all `CHANGE_ME` values replaced, JSON valid, permissions `640`
- [ ] `/opt/olt_checker.py` installed, permissions `750`
- [ ] `/var/www/html/get_olt_signal.php` installed
- [ ] Test 1 passed (database returns MAC)
- [ ] Test 2 passed for every OLT (reachable over SSH)
- [ ] Test 3 passed (full lookup returns optical values)
- [ ] Test 4 passed (web bridge returns JSON)
- [ ] Test 5 passed (button shows values in the browser)

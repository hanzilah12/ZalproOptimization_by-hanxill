<?php
/**
 * get_olt_signal.php
 *
 * Bridge between the Zalpro profile page and the Python OLT checker.
 * Receives a username via GET, runs olt_checker.py, and returns JSON.
 *
 * Location: /var/www/html/get_olt_signal.php
 */

header('Content-Type: application/json');

// The Python search can take up to about one minute on large networks.
set_time_limit(120);

$user = isset($_GET['user']) ? trim($_GET['user']) : '';

if ($user === '') {
    echo json_encode(['status' => 'error', 'message' => 'Username parameter missing']);
    exit;
}

// IMPORTANT: Keep this validation. This endpoint runs a shell command,
// so the username must never contain shell characters.
if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $user)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid username format']);
    exit;
}

// stderr is discarded so that warnings never corrupt the JSON output.
$command = 'python3 /opt/olt_checker.py --user ' . escapeshellarg($user) . ' --json 2>/dev/null';
$output = shell_exec($command);

if ($output !== null && json_decode($output) !== null) {
    echo $output;
} else {
    echo json_encode(['status' => 'error', 'message' => 'No valid response from OLT checker']);
}
?>

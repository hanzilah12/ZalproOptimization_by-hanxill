NetPoint Live Traffic Monitor - Upload Files
=============================================

This folder mirrors the server paths. Upload it with WinSCP, then copy
the files into place with the commands below.

FILES
-----
opt/netpoint-traffic/monitor.py          -> /opt/netpoint-traffic/monitor.py
var/www/html/traffic/start.php           -> /var/www/html/traffic/start.php
var/www/html/traffic/stop.php            -> /var/www/html/traffic/stop.php
var/www/html/traffic/heartbeat.php       -> /var/www/html/traffic/heartbeat.php
var/www/html/traffic/status.php          -> /var/www/html/traffic/status.php
var/www/html/traffic/panel.php           -> /var/www/html/traffic/panel.php


STEP 1 - Upload with WinSCP
---------------------------
1. Connect to the Zalpro server in WinSCP.
2. In the right pane (server), open your home folder (for example /home/<your-user>).
3. Create a folder named: netpoint-traffic
4. Drag the contents of this folder (opt/ and var/) into it.
   Result on server:
     /home/<your-user>/netpoint-traffic/opt/netpoint-traffic/monitor.py
     /home/<your-user>/netpoint-traffic/var/www/html/traffic/*.php


STEP 2 - Copy into place (run on the server, as root or with sudo)
-------------------------------------------------------------------
Replace <your-user> with your actual home folder name.

  SRC=/home/<your-user>/netpoint-traffic

  sudo mkdir -p /opt/netpoint-traffic /var/lib/netpoint-traffic/data /var/www/html/traffic

  sudo cp $SRC/opt/netpoint-traffic/monitor.py /opt/netpoint-traffic/monitor.py
  sudo cp $SRC/var/www/html/traffic/*.php /var/www/html/traffic/


STEP 3 - Set ownership and permissions
--------------------------------------
  sudo chown root:www-data /opt/netpoint-traffic/monitor.py
  sudo chmod 640 /opt/netpoint-traffic/monitor.py

  sudo chown -R www-data:www-data /var/lib/netpoint-traffic
  sudo chmod 755 /var/lib/netpoint-traffic /var/lib/netpoint-traffic/data

  sudo chown -R www-data:www-data /var/www/html/traffic
  sudo chmod 644 /var/www/html/traffic/*.php


STEP 4 - Edit the configuration (required)
------------------------------------------
  sudo nano /opt/netpoint-traffic/monitor.py

Set the real value for:
  SSH_PASS = "..."

Save and exit.


STEP 5 - Check syntax
---------------------
  php -l /var/www/html/traffic/start.php
  php -l /var/www/html/traffic/stop.php
  php -l /var/www/html/traffic/heartbeat.php
  php -l /var/www/html/traffic/status.php
  php -l /var/www/html/traffic/panel.php
  python3 -m py_compile /opt/netpoint-traffic/monitor.py && echo "monitor.py OK"


STEP 6 - Add the panel to the profile page
------------------------------------------
Edit the profile page and add this line where the Live Traffic panel
should appear (where $user is available):

  <?php include '/var/www/html/traffic/panel.php'; ?>

  sudo nano /var/www/html/application/views/themes/legacy/admin_portal/users/profile.php

Remove any old line that includes traffic-chart.php.

If the username variable in the profile page is not $user->username,
change the first line of /var/www/html/traffic/panel.php to match.


STEP 7 - Reload the web server
------------------------------
  sudo systemctl reload apache2      (or: sudo systemctl reload nginx)


STEP 8 - Test
-------------
Open a user profile, press Ctrl+F5, then click "Start monitoring".
See the full guide (NetPoint_Live_Traffic_Monitor_Guide.md) for detailed
tests, troubleshooting, and the security checklist.


IMPORTANT
---------
- Add the Zalpro admin login check to start.php, stop.php, heartbeat.php,
  and status.php before production use (see guide, Section 11).
- Change the Juniper password, which was shared in plain text during setup.

<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
// TODO: add the Zalpro admin session check here (see guide, Section 11).

$user = trim($_GET['username'] ?? '');
if (!preg_match('/^[\w.@-]{1,64}$/', $user)) {
    echo json_encode(['state' => 'error', 'text' => 'Invalid username']);
    exit;
}

$file = "/var/lib/netpoint-traffic/data/$user.json";
if (!file_exists($file)) {
    echo json_encode(['state' => 'idle', 'text' => 'Idle']);
    exit;
}

$state = json_decode(file_get_contents($file), true) ?: [];

// If the monitor has not updated for 20 seconds while "running", treat it as failed
if (($state['state'] ?? '') === 'running' && time() - ($state['updated'] ?? 0) > 20) {
    $state['state'] = 'error';
    $state['text']  = 'Monitor not responding';
    $state['down']  = 0;
    $state['up']    = 0;
}

echo json_encode($state);

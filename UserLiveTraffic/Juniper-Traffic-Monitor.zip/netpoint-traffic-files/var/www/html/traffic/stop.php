<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
// TODO: add the Zalpro admin session check here (see guide, Section 11).
// Accepts GET (manual button) and POST (navigator.sendBeacon on page close).

$user = trim($_GET['username'] ?? $_POST['username'] ?? '');
if (!preg_match('/^[\w.@-]{1,64}$/', $user)) {
    echo json_encode(['ok' => false, 'error' => 'Invalid username']);
    exit;
}

file_put_contents("/var/lib/netpoint-traffic/data/$user.stop", '1');
echo json_encode(['ok' => true]);

<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
// TODO: add the Zalpro admin session check here (see guide, Section 11).

$user = trim($_GET['username'] ?? '');
if (!preg_match('/^[\w.@-]{1,64}$/', $user)) {
    echo json_encode(['ok' => false, 'error' => 'Invalid username']);
    exit;
}

$dir     = '/var/lib/netpoint-traffic/data';
$monitor = '/opt/netpoint-traffic/monitor.py';
$pidFile = "$dir/$user.pid";

// Stop any previous monitor so every start performs a fresh interface lookup
if (file_exists($pidFile)) {
    $oldPid = (int) trim((string) @file_get_contents($pidFile));
    if ($oldPid > 0) {
        exec("kill $oldPid 2>/dev/null");
    }
    @unlink($pidFile);
}

// Reset all per-session files
@unlink("$dir/$user.stop");
file_put_contents("$dir/$user.hb", (string) time());
file_put_contents("$dir/$user.json", json_encode([
    'state'     => 'running',
    'text'      => 'Starting...',
    'interface' => '-',
    'down'      => 0,
    'up'        => 0,
    'remaining' => 180,
    'updated'   => time(),
    'history'   => [],
]));

// Launch the monitor in the background
exec(sprintf(
    'nohup python3 %s %s > %s 2>&1 &',
    escapeshellarg($monitor),
    escapeshellarg($user),
    escapeshellarg("$dir/$user.log")
));

echo json_encode(['ok' => true]);

<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
// TODO: add the Zalpro admin session check here (see guide, Section 11).

$user = trim($_GET['username'] ?? '');
if (!preg_match('/^[\w.@-]{1,64}$/', $user)) {
    echo json_encode(['ok' => false]);
    exit;
}

touch("/var/lib/netpoint-traffic/data/$user.hb");
echo json_encode(['ok' => true]);

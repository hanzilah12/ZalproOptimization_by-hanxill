<?php $trafficUser = trim($user->username ?? ''); ?>
<style>
  .tm-card { background:#0f172a; color:#e2e8f0; border-radius:12px; padding:20px; margin-top:16px; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; }
  .tm-head { display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; }
  .tm-title { font-size:15px; font-weight:600; letter-spacing:.2px; }
  .tm-pill { font-size:12px; padding:4px 10px; border-radius:999px; background:#1e293b; color:#94a3b8; display:flex; gap:7px; align-items:center; }
  .tm-dot { width:8px; height:8px; border-radius:50%; background:#64748b; }
  .tm-pill.live { color:#86efac; }
  .tm-pill.live .tm-dot { background:#22c55e; box-shadow:0 0 0 4px rgba(34,197,94,.18); }
  .tm-pill.wait { color:#fcd34d; }
  .tm-pill.wait .tm-dot { background:#f59e0b; animation:tmPulse 1.2s infinite; }
  .tm-pill.err { color:#fca5a5; }
  .tm-pill.err .tm-dot { background:#ef4444; }
  @keyframes tmPulse { 50% { opacity:.25; } }
  .tm-metrics { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .tm-metric { background:#111c31; border:1px solid #1e2d47; border-radius:10px; padding:14px 16px; }
  .tm-label { font-size:11px; text-transform:uppercase; letter-spacing:.08em; color:#64748b; }
  .tm-value { font-size:28px; font-weight:600; margin-top:6px; font-variant-numeric:tabular-nums; white-space:nowrap; }
  .tm-value small { font-size:13px; font-weight:500; color:#94a3b8; margin-left:4px; }
  .tm-down .tm-value { color:#38bdf8; }
  .tm-up .tm-value { color:#fbbf24; }
  .tm-meta { display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap; margin:16px 0 8px; font-size:12px; color:#94a3b8; }
  .tm-meta b { color:#e2e8f0; font-weight:500; font-variant-numeric:tabular-nums; }
  .tm-bar { height:3px; background:#1e293b; border-radius:2px; overflow:hidden; }
  .tm-bar > div { height:100%; width:0; background:#38bdf8; transition:width .9s linear; }
  .tm-chart-head { display:flex; justify-content:space-between; font-size:11px; color:#64748b; margin-top:16px; }
  .tm-chart { width:100%; height:170px; display:block; margin-top:6px; }
  .tm-actions { display:flex; gap:10px; margin-top:16px; }
  .tm-btn { flex:1; padding:10px 0; border-radius:8px; font-size:14px; font-weight:600; cursor:pointer; border:1px solid transparent; }
  .tm-btn:disabled { opacity:.35; cursor:not-allowed; }
  .tm-start { background:#2563eb; color:#fff; }
  .tm-start:hover:not(:disabled) { background:#1d4ed8; }
  .tm-stop { background:transparent; color:#f87171; border-color:#7f1d1d; }
  .tm-stop:hover:not(:disabled) { background:#2a1215; }
  .tm-note { font-size:11px; color:#475569; margin-top:12px; }
</style>

<div class="tm-card" id="tmCard">
  <div class="tm-head">
    <div class="tm-title">Live Traffic</div>
    <div class="tm-pill" id="tmPill"><span class="tm-dot"></span><span id="tmPillText">Idle</span></div>
  </div>

  <div class="tm-metrics">
    <div class="tm-metric tm-down">
      <div class="tm-label">Download</div>
      <div class="tm-value" id="tmDown">0<small>bps</small></div>
    </div>
    <div class="tm-metric tm-up">
      <div class="tm-label">Upload</div>
      <div class="tm-value" id="tmUp">0<small>bps</small></div>
    </div>
  </div>

  <div class="tm-meta">
    <span>Interface <b id="tmIface">-</b></span>
    <span>Auto-stop in <b id="tmLeft">03:00</b></span>
  </div>
  <div class="tm-bar"><div id="tmBar"></div></div>

  <div class="tm-chart-head">
    <span>Last 60 seconds</span>
    <span id="tmPeak"></span>
  </div>
  <canvas id="tmChart" class="tm-chart"></canvas>

  <div class="tm-actions">
    <button id="tmStart" class="tm-btn tm-start">Start monitoring</button>
    <button id="tmStop" class="tm-btn tm-stop" disabled>Stop</button>
  </div>
  <div class="tm-note">The monitor runs only while this page is open. It stops automatically when you refresh or close the page.</div>
</div>

<script>
(function () {
  const USER = <?= json_encode($trafficUser) ?>;
  const AUTO = 180;
  const $ = id => document.getElementById(id);
  const URL = {
    status: "/traffic/status.php?username=",
    start:  "/traffic/start.php?username=",
    stop:   "/traffic/stop.php?username=",
    hb:     "/traffic/heartbeat.php?username="
  };
  const enc = encodeURIComponent(USER);

  let running = false;
  let hist = [];          // Array of [download_bps, upload_bps] from the server
  let pollTimer = null;
  let hbTimer = null;

  // Display only: converts bits per second to a readable unit (1000 steps)
  function fmt(bps) {
    if (bps < 1e3) return [bps.toFixed(0), "bps"];
    if (bps < 1e6) return [(bps / 1e3).toFixed(2), "Kbps"];
    if (bps < 1e9) return [(bps / 1e6).toFixed(2), "Mbps"];
    return [(bps / 1e9).toFixed(2), "Gbps"];
  }

  function setValue(id, bps) {
    const [value, unit] = fmt(bps || 0);
    $(id).innerHTML = value + "<small>" + unit + "</small>";
  }

  function setPill(kind, text) {
    $("tmPill").className = "tm-pill" + (kind ? " " + kind : "");
    $("tmPillText").textContent = text;
  }

  function setControls(on) {
    running = on;
    $("tmStart").disabled = on;
    $("tmStop").disabled = !on;
  }

  function setTimer(seconds) {
    const s = Math.max(0, seconds || 0);
    $("tmLeft").textContent = String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
    $("tmBar").style.width = (s / AUTO * 100) + "%";
  }

  function draw() {
    const canvas = $("tmChart");
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    }
    const g = canvas.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);

    const top = 8, bottom = h - 4;
    g.strokeStyle = "#1e293b";
    g.lineWidth = 1;
    for (let i = 0; i <= 3; i++) {
      const y = top + (bottom - top) * i / 3;
      g.beginPath(); g.moveTo(0, y + 0.5); g.lineTo(w, y + 0.5); g.stroke();
    }

    const peak = Math.max(1, ...hist.map(p => Math.max(p[0], p[1])));
    $("tmPeak").textContent = hist.length ? "Peak " + fmt(peak).join(" ") : "";

    if (hist.length < 2) {
      g.fillStyle = "#475569";
      g.font = "12px system-ui";
      g.textAlign = "center";
      g.fillText(running ? "Waiting for data..." : "Press Start to begin the graph", w / 2, h / 2);
      return;
    }

    const step = w / 59;
    const point = (i, idx) => [
      w - (hist.length - 1 - i) * step,
      bottom - (bottom - top) * (hist[i][idx] / peak)
    ];

    // Download area fill
    const gradient = g.createLinearGradient(0, top, 0, bottom);
    gradient.addColorStop(0, "rgba(56,189,248,0.35)");
    gradient.addColorStop(1, "rgba(56,189,248,0)");
    g.beginPath();
    hist.forEach((_, i) => {
      const [x, y] = point(i, 0);
      if (i) { g.lineTo(x, y); } else { g.moveTo(x, y); }
    });
    const lastX = point(hist.length - 1, 0)[0];
    const firstX = point(0, 0)[0];
    g.lineTo(lastX, bottom);
    g.lineTo(firstX, bottom);
    g.closePath();
    g.fillStyle = gradient;
    g.fill();

    // Download and upload lines
    [[0, "#38bdf8"], [1, "#fbbf24"]].forEach(([idx, color]) => {
      g.beginPath();
      g.strokeStyle = color;
      g.lineWidth = 1.8;
      g.lineJoin = "round";
      hist.forEach((_, i) => {
        const [x, y] = point(i, idx);
        if (i) { g.lineTo(x, y); } else { g.moveTo(x, y); }
      });
      g.stroke();
    });
  }

  function render(state) {
    const iface = state.interface && state.interface !== "-" ? state.interface : "Resolving...";
    $("tmIface").textContent = iface;
    setValue("tmDown", state.down);
    setValue("tmUp", state.up);
    setTimer(state.remaining);
    hist = state.history || [];
    draw();

    if (state.state === "error") {
      setPill("err", state.text || "Error");
    } else if (state.text === "Live") {
      setPill("live", "Live");
    } else {
      setPill("wait", state.text || "Connecting...");
    }
  }

  function resetUI(text) {
    hist = [];
    $("tmIface").textContent = "-";
    setValue("tmDown", 0);
    setValue("tmUp", 0);
    setTimer(AUTO);
    setPill("", text || "Idle");
    draw();
  }

  function sendHeartbeat() {
    fetch(URL.hb + enc, { cache: "no-store" }).catch(() => {});
  }

  function stopHeartbeat() {
    if (hbTimer) {
      clearInterval(hbTimer);
      hbTimer = null;
    }
  }

  async function poll() {
    pollTimer = null;
    if (!running) return;
    try {
      const state = await (await fetch(URL.status + enc, { cache: "no-store" })).json();
      render(state);
      if (state.state === "running") {
        pollTimer = setTimeout(poll, 1000);
      } else {
        finish(state.state === "error");
      }
    } catch (e) {
      setPill("wait", "Reconnecting...");
      pollTimer = setTimeout(poll, 2000);
    }
  }

  function finish(isError) {
    setControls(false);
    stopHeartbeat();
    if (pollTimer) {
      clearTimeout(pollTimer);
      pollTimer = null;
    }
    if (!isError) setPill("", "Stopped");
  }

  async function startMonitor() {
    if (running) return;
    setControls(true);
    resetUI("Resolving interface...");
    try {
      const result = await (await fetch(URL.start + enc, { cache: "no-store" })).json();
      if (!result.ok) {
        setPill("err", result.error || "Start failed");
        setControls(false);
        return;
      }
    } catch (e) {
      setPill("err", "Start request failed");
      setControls(false);
      return;
    }
    sendHeartbeat();
    hbTimer = setInterval(sendHeartbeat, 5000);
    poll();
  }

  function stopMonitor() {
    if (!running) return;
    stopHeartbeat();
    if (pollTimer) {
      clearTimeout(pollTimer);
      pollTimer = null;
    }
    setControls(false);
    setPill("", "Stopping...");
    fetch(URL.stop + enc, { cache: "no-store" })
      .then(() => setPill("", "Stopped"))
      .catch(() => setPill("err", "Stop request failed"));
  }

  // Page refresh, navigation, or tab close: stop the monitor immediately
  window.addEventListener("pagehide", () => {
    if (running && navigator.sendBeacon) {
      navigator.sendBeacon(URL.stop + enc);
    }
  });

  // Page load: stop any monitor left running from an earlier session, then start from Idle
  (async () => {
    resetUI("Idle");
    try {
      const state = await (await fetch(URL.status + enc, { cache: "no-store" })).json();
      if (state.state === "running") {
        await fetch(URL.stop + enc, { cache: "no-store" });
      }
    } catch (e) {
      // Ignore; the panel still works without this check
    }
  })();

  $("tmStart").onclick = startMonitor;
  $("tmStop").onclick = stopMonitor;
  window.addEventListener("resize", draw);
})();
</script>

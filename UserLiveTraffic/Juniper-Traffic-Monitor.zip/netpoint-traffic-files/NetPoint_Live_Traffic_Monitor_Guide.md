# NetPoint Live Traffic Monitor for Zalpro

**Installation Guide and Source Files**
Target: Zalpro server (Ubuntu, Apache/PHP, Python 3.6+) and Juniper MX104 BNG
Version: 1.0

---

## Table of Contents

1. [Overview](#1-overview)
2. [How It Works](#2-how-it-works)
3. [Requirements](#3-requirements)
4. [Final Directory Layout](#4-final-directory-layout)
5. [Remove the Previous Setup](#5-remove-the-previous-setup)
6. [Installation](#6-installation)
7. [Source Files](#7-source-files)
8. [Verification and Testing](#8-verification-and-testing)
9. [Operating the Monitor](#9-operating-the-monitor)
10. [Troubleshooting](#10-troubleshooting)
11. [Security Recommendations](#11-security-recommendations)
12. [Configuration Reference](#12-configuration-reference)
13. [Known Limitations](#13-known-limitations)

---

## 1. Overview

This feature adds a **Live Traffic** panel to the Zalpro user profile page. When an administrator clicks **Start monitoring**, the system:

- Resolves the subscriber's current PPPoE logical interface (`pp0.X`) on the Juniper MX104, fresh on every start.
- Streams the subscriber's live download and upload rates (bits per second) to the browser.
- Draws a 60-second throughput graph.
- Stops automatically when the admin clicks **Stop**, refreshes or closes the page, or after 3 minutes.

No WebSocket server, no background service, and no permanent process are used. The monitor runs only while the page is open.

---

## 2. How It Works

### 2.1 Component summary

| Component | Location | Role |
|---|---|---|
| `panel.php` | `/var/www/html/traffic/` | Profile page UI (HTML, CSS, JavaScript). Included in the profile page. |
| `start.php` | `/var/www/html/traffic/` | Stops any previous monitor, resets state, launches `monitor.py`. |
| `stop.php` | `/var/www/html/traffic/` | Creates a stop flag file for the running monitor. |
| `heartbeat.php` | `/var/www/html/traffic/` | Updates the heartbeat timestamp while the page is open. |
| `status.php` | `/var/www/html/traffic/` | Returns the current monitor state as JSON. |
| `monitor.py` | `/opt/netpoint-traffic/` | SSH session to Juniper. Resolves the interface and writes live samples. |
| Data directory | `/var/lib/netpoint-traffic/data/` | Per-user state (`.json`), heartbeat (`.hb`), stop flag (`.stop`), PID (`.pid`), and log (`.log`) files. |

Keeping `monitor.py` and its password outside the web root (`/opt`) prevents browsers from reading it.

### 2.2 Step-by-step flow

1. **Page load.** `panel.php` checks `status.php`. If a monitor is running for this user, it is stopped. The UI starts in the **Idle** state.
2. **Start.** The admin clicks **Start monitoring**.
   - `start.php` kills any old monitor for that user (from its `.pid` file).
   - It removes old stop flags and writes a fresh state file with `state: running`.
   - It starts `monitor.py <username>` in the background with `nohup`.
3. **Interface resolution.** `monitor.py` opens an SSH session to the Juniper and runs `show subscribers user-name <username>`. It extracts the `pp0.X` interface from the output. If the subscriber is offline, it retries every 2 seconds.
4. **Live monitoring.** `monitor.py` runs `monitor interface pp0.X`. The Junos screen refreshes about once per second with `Input bytes ... (N bps)` and `Output bytes ... (N bps)`. The `pyte` library renders the terminal output so the values can be parsed reliably. Each new sample is written to the state file with the last 60 samples as history.
5. **Heartbeat.** While the page is open, the browser calls `heartbeat.php` every 5 seconds. This updates the `.hb` file timestamp.
6. **Browser polling.** The browser calls `status.php` every second and updates the numbers and graph from the JSON response.
7. **Stop conditions.** The monitor exits when any of the following occurs:
   - The admin clicks **Stop** (`stop.php` creates the `.stop` file).
   - The page is refreshed or closed (the browser sends a `sendBeacon` stop request on `pagehide`).
   - The heartbeat is older than 20 seconds (for example, if the browser crashed or lost network).
   - 180 seconds have elapsed (auto-stop).
8. **Cleanup.** The monitor closes the SSH session, removes its stop, heartbeat, and PID files, and writes `state: stopped`.

### 2.3 Where the speed comes from

The router calculates the rate. The application only reads and displays it.

- Juniper prints `(N bps)` in the `monitor interface` output. This is the average rate the router computes for the interface.
- `monitor.py` stores that value unchanged, in bits per second.
- The browser converts bps to Kbps, Mbps, or Gbps for display only, dividing by 1,000 for each step.

Mapping used:

- `Output bps` on the interface is shown as **Download** (router to subscriber).
- `Input bps` on the interface is shown as **Upload** (subscriber to router).

---

## 3. Requirements

### 3.1 Zalpro server

- Ubuntu server with Apache (or Nginx) and PHP, where the Zalpro web application runs.
- PHP `exec()` function enabled. Verify with:
  ```bash
  php -r 'echo function_exists("exec") ? "exec OK\n" : "exec DISABLED\n";'
  ```
- Python 3 available as `python3`.
- Python packages `paramiko` and `pyte`.
- Network access from Zalpro to the Juniper SSH port (default `8877`).
- Root or sudo access for installation.

### 3.2 Juniper MX104

- SSH access on port `8877` for a user with sufficient privileges to run `show subscribers` and `monitor interface`.
- See [Section 11](#11-security-recommendations) for recommended permissions.

### 3.3 Python package note

On the current Zalpro server, Python 3.6 is installed and `pip3` does not support the `--break-system-packages` option. The packages were already present in the system site-packages, so no installation with that flag is needed. Verify the packages with the command in Step 6.2.

---

## 4. Final Directory Layout

```
/opt/netpoint-traffic/
└── monitor.py                       # Juniper SSH monitor (not web-accessible)

/var/lib/netpoint-traffic/
└── data/                            # Runtime state (owned by www-data)
    ├── <username>.json              # Current state and history
    ├── <username>.hb                # Heartbeat timestamp
    ├── <username>.stop              # Stop flag (temporary)
    ├── <username>.pid               # Monitor process ID
    └── <username>.log               # Monitor stdout/stderr

/var/www/html/traffic/               # Web-accessible endpoints (owned by www-data)
├── panel.php                        # UI panel, included in the profile page
├── start.php                        # Start monitor
├── stop.php                         # Stop monitor
├── heartbeat.php                    # Keep-alive from browser
└── status.php                       # Current state as JSON
```

---

## 5. Remove the Previous Setup

If you installed the earlier WebSocket-based version or the first version of the panel, remove it first. Create a backup before deleting anything.

### 5.1 Backup

```bash
sudo mkdir -p /root/traffic-backup
sudo tar czf /root/traffic-backup/old-traffic-$(date +%F).tar.gz \
    /zalpro-optimization/new-user-traffic \
    /var/www/html/traffic \
    /var/www/html/application/views/themes/legacy/admin_portal/users/profile.php 2>/dev/null
```

### 5.2 Stop old services and processes

```bash
sudo systemctl disable --now traffic-ws 2>/dev/null
sudo rm -f /etc/systemd/system/traffic-ws.service
sudo systemctl daemon-reload

pkill -f monitor_server.py 2>/dev/null
crontab -l 2>/dev/null | grep -v monitor_server.py | crontab -
```

### 5.3 Remove old files and symlinks

```bash
sudo rm -f /var/www/html/get_live_traffic.php
sudo rm -f /var/www/html/get_user_interface.php
sudo rm -f /var/www/html/get_traffic_token.php
sudo rm -rf /zalpro-optimization/new-user-traffic
sudo rm -rf /zalpro-optimization/live-traffic
sudo rm -f /zalpro-optimization/monitor_server.log
```

### 5.4 Remove the old profile include

```bash
grep -n "traffic" /var/www/html/application/views/themes/legacy/admin_portal/users/profile.php
```

Remove any line that includes `traffic-chart.php` (or any other old traffic file). Keep only the include from [Step 6.8](#68-add-the-panel-to-the-profile-page). Use `nano` to edit the file, then save.

> **Do NOT remove:**
> - The Zalpro netplan route and routing policy for `103.170.179.40` (required for CoA and disconnect traffic).
> - The Juniper `zalpro-api` SSH key and REST API configuration, unless you have confirmed that no other Zalpro feature uses them.

---

## 6. Installation

Perform these steps in order. Run commands as `root` or with `sudo`.

### 6.1 Create directories

```bash
sudo mkdir -p /opt/netpoint-traffic
sudo mkdir -p /var/lib/netpoint-traffic/data
sudo mkdir -p /var/www/html/traffic
```

### 6.2 Verify Python packages

```bash
sudo -u www-data python3 -c "import paramiko, pyte; print('OK')"
```

Expected output: `OK`

If the import fails, install the packages:

```bash
sudo pip3 install paramiko pyte
```

Then repeat the verification command.

### 6.3 Set ownership and permissions

```bash
sudo chown -R www-data:www-data /var/lib/netpoint-traffic
sudo chmod 755 /var/lib/netpoint-traffic
sudo chmod 755 /var/lib/netpoint-traffic/data

sudo chown root:www-data /opt/netpoint-traffic
sudo chmod 750 /opt/netpoint-traffic
```

### 6.4 Create the monitor script

```bash
sudo nano /opt/netpoint-traffic/monitor.py
```

Paste the content from [Section 7.1](#71-optmonitorpy). Before saving, set your real SSH credentials in the `CONFIG` block.

Then set permissions so the web server can run it but cannot be browsed:

```bash
sudo chown root:www-data /opt/netpoint-traffic/monitor.py
sudo chmod 640 /opt/netpoint-traffic/monitor.py
```

> **Note:** `www-data` must be able to read `monitor.py` to run it. Mode `640` with group `www-data` allows this.

### 6.5 Create the web endpoints

Create each file below and paste the content from [Section 7](#7-source-files):

```bash
sudo nano /var/www/html/traffic/start.php        # Section 7.2
sudo nano /var/www/html/traffic/stop.php         # Section 7.3
sudo nano /var/www/html/traffic/heartbeat.php    # Section 7.4
sudo nano /var/www/html/traffic/status.php       # Section 7.5
sudo nano /var/www/html/traffic/panel.php        # Section 7.6
```

### 6.6 Set web directory ownership

```bash
sudo chown -R www-data:www-data /var/www/html/traffic
sudo chmod 755 /var/www/html/traffic
sudo chmod 644 /var/www/html/traffic/*.php
```

### 6.7 Check syntax

```bash
php -l /var/www/html/traffic/start.php
php -l /var/www/html/traffic/stop.php
php -l /var/www/html/traffic/heartbeat.php
php -l /var/www/html/traffic/status.php
php -l /var/www/html/traffic/panel.php
python3 -m py_compile /opt/netpoint-traffic/monitor.py && echo "monitor.py OK"
```

Each PHP file should report `No syntax errors detected`. Python should print `monitor.py OK`.

### 6.8 Add the panel to the profile page

Open the profile page:

```bash
sudo nano /var/www/html/application/views/themes/legacy/admin_portal/users/profile.php
```

Add this line where the Live Traffic panel should appear (inside the user profile view, where `$user` is available):

```php
<?php include '/var/www/html/traffic/panel.php'; ?>
```

> **Important:** The panel reads the username from `$user->username`. This variable is already used in the profile page. If the variable name in your profile page is different, change the first line of `panel.php` accordingly.

Verify:

```bash
grep -n "traffic" /var/www/html/application/views/themes/legacy/admin_portal/users/profile.php
```

Only the `panel.php` include should be listed.

### 6.9 Reload the web server

```bash
sudo systemctl reload apache2     # or: sudo systemctl reload nginx
```

### 6.10 Installation checklist

- [ ] Packages `paramiko` and `pyte` import successfully as `www-data`.
- [ ] `/opt/netpoint-traffic/monitor.py` contains the real SSH credentials.
- [ ] All five web files exist in `/var/www/html/traffic/`.
- [ ] All PHP files pass `php -l`.
- [ ] `monitor.py` passes `py_compile`.
- [ ] The profile page includes only `panel.php` for traffic.
- [ ] Old WebSocket service and cron entries are removed.
- [ ] The web server has been reloaded.

---

## 7. Source Files

### 7.1 `/opt/netpoint-traffic/monitor.py`

```python
#!/usr/bin/env python3
"""
NetPoint Live Traffic Monitor - Juniper MX104 SSH monitor.

Usage:
    monitor.py <pppoe_username>

Resolves the subscriber's active pp0.X logical interface on each start,
runs 'monitor interface' on the router, parses the bps values from the
terminal output, and writes the state to a JSON file that the web panel reads.
The process stops on stop flag, stale heartbeat, auto-stop timeout, or error.
"""
import json
import os
import re
import socket
import sys
import time

import paramiko
import pyte

# ---------------------------------------------------------------
# CONFIGURATION - set these values before deployment
# ---------------------------------------------------------------
ROUTER_IP = "103.170.179.40"
SSH_PORT = 8877
SSH_USER = "hanxill"              # Recommended: a dedicated, limited-permission user
SSH_PASS = "CHANGE_ME"            # Set the real password here
AUTO_STOP = 180                   # Maximum monitoring duration in seconds
HB_TIMEOUT = 20                   # Stop if no browser heartbeat for this many seconds
DATA = "/var/lib/netpoint-traffic/data"
HISTORY_LEN = 60                  # Number of samples kept for the graph
# ---------------------------------------------------------------

COLS, ROWS = 120, 40
PROMPT = re.compile(r"\S+@\S+[>#] \Z")
IN_RE = re.compile(r"Input\s+bytes:\s*\d+\s*\(\s*(\d+)\s*bps\s*\)")
OUT_RE = re.compile(r"Output\s+bytes:\s*\d+\s*\(\s*(\d+)\s*bps\s*\)")
SEC_RE = re.compile(r"Seconds:\s*(\d+)")
ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b[()][A-Za-z0-9]|\r")


class Shell:
    """Interactive SSH shell helper for Junos CLI commands."""

    def __init__(self, host, user, password, port):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.client.connect(
            host,
            port=port,
            username=user,
            password=password,
            timeout=8,
            look_for_keys=False,
            allow_agent=False,
        )
        self.channel = self.client.invoke_shell(width=1000, height=1000)
        self.channel.settimeout(0.2)
        self._read(8)
        self.run("set cli screen-length 0")
        self.run("set cli screen-width 1000")

    def _read(self, timeout):
        """Read until the CLI prompt appears or the timeout expires."""
        buf, end = "", time.monotonic() + timeout
        while time.monotonic() < end:
            try:
                data = self.channel.recv(65535)
                if not data:
                    raise ConnectionError("SSH session closed")
                buf += data.decode(errors="replace")
            except socket.timeout:
                pass
            if PROMPT.search(buf):
                return buf
        raise TimeoutError("Router did not answer in time")

    def run(self, command, timeout=6):
        self.channel.send(command + "\n")
        return self._read(timeout)

    def close(self):
        try:
            self.client.close()
        except Exception:
            pass


def write_status(user, state):
    """Atomically write the state file so the web panel never reads a partial file."""
    path = os.path.join(DATA, user + ".json")
    tmp = path + ".tmp"
    with open(tmp, "w") as handle:
        json.dump(state, handle)
    os.replace(tmp, path)


def remove_quiet(path):
    try:
        os.remove(path)
    except OSError:
        pass


def main():
    user = sys.argv[1]
    stop_file = os.path.join(DATA, user + ".stop")
    hb_file = os.path.join(DATA, user + ".hb")
    pid_file = os.path.join(DATA, user + ".pid")
    deadline = time.monotonic() + AUTO_STOP
    reason = {"text": "Stopped"}

    with open(pid_file, "w") as handle:
        handle.write(str(os.getpid()))

    state = {
        "state": "running",
        "text": "Connecting...",
        "interface": "-",
        "down": 0,
        "up": 0,
        "remaining": AUTO_STOP,
        "updated": time.time(),
        "history": [],
    }

    def save(**fields):
        state.update(fields)
        state["remaining"] = max(0, int(deadline - time.monotonic()))
        state["updated"] = time.time()
        write_status(user, state)

    def should_stop():
        if os.path.exists(stop_file):
            reason["text"] = "Stopped"
            return True
        if time.monotonic() >= deadline:
            reason["text"] = "Auto-stopped after 3 minutes"
            return True
        try:
            if time.time() - os.path.getmtime(hb_file) > HB_TIMEOUT:
                reason["text"] = "Page closed or refreshed, monitor stopped"
                return True
        except OSError:
            reason["text"] = "Stopped"
            return True
        return False

    shell = None
    try:
        save()
        shell = Shell(ROUTER_IP, SSH_USER, SSH_PASS, SSH_PORT)

        while not should_stop():
            # Fresh interface lookup on every iteration
            output = shell.run("show subscribers user-name %s" % user)
            match = re.search(r"\b(pp0\.\d+)\b", output)
            if not match:
                save(text="Subscriber offline, retrying...", interface="-", down=0, up=0)
                time.sleep(2)
                continue

            ifl = match.group(1)
            save(text="Reading live traffic...", interface=ifl)

            shell.channel.resize_pty(width=COLS, height=ROWS)
            screen = pyte.Screen(COLS, ROWS)
            stream = pyte.Stream(screen)
            shell.channel.send("monitor interface %s\n" % ifl)

            last_update = time.monotonic()
            last_sec, tail = None, ""

            while not should_stop():
                try:
                    data = shell.channel.recv(65535)
                    if not data:
                        raise ConnectionError("SSH session closed")
                    chunk = data.decode(errors="replace")
                    stream.feed(chunk)
                    tail = (tail + ANSI.sub("", chunk))[-300:]
                except socket.timeout:
                    pass

                text = "\n".join(screen.display)
                now = time.monotonic()
                match_in = IN_RE.search(text)
                match_out = OUT_RE.search(text)

                if match_in and match_out:
                    sec_match = SEC_RE.search(text)
                    sec = sec_match.group(1) if sec_match else None
                    if sec is not None:
                        fresh = sec != last_sec
                    else:
                        fresh = now - last_update >= 1.0

                    if fresh and now - last_update >= 0.3:
                        last_update, last_sec = now, sec
                        down = int(match_out.group(1))   # Output = subscriber download
                        up = int(match_in.group(1))      # Input  = subscriber upload
                        history = state["history"]
                        history.append([down, up])
                        del history[:-HISTORY_LEN]
                        save(text="Live", down=down, up=up, interface=ifl)

                # Prompt returned or no data for 6 seconds: resolve the interface again
                if PROMPT.search(tail) or now - last_update > 6:
                    break

            try:
                shell.channel.send("q")
                shell._read(4)
            except Exception:
                pass

        save(state="stopped", text=reason["text"], interface="-",
             down=0, up=0, history=[])

    except Exception as exc:
        save(state="error", text="Error: %s" % exc, interface="-",
             down=0, up=0, history=[])

    finally:
        if shell:
            shell.close()
        remove_quiet(stop_file)
        remove_quiet(hb_file)
        try:
            with open(pid_file) as handle:
                if handle.read().strip() == str(os.getpid()):
                    remove_quiet(pid_file)
        except OSError:
            pass


if __name__ == "__main__":
    main()
```

---

### 7.2 `/var/www/html/traffic/start.php`

```php
<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
// TODO: add the Zalpro admin session check here (see Section 11).

$user = trim($_GET['username'] ?? '');
if (!preg_match('/^[\w.@-]{1,64}$/', $user)) {
    echo json_encode(['ok' => false, 'error' => 'Invalid username']);
    exit;
}

$dir     = '/var/lib/netpoint-traffic/data';
$monitor = '/opt/netpoint-traffic/monitor.py';
$pidFile = "$dir/$user.pid";

// Stop any previous monitor so every start performs a fresh interface lookup
if (file_exists($pidFile)) {
    $oldPid = (int) trim((string) @file_get_contents($pidFile));
    if ($oldPid > 0) {
        exec("kill $oldPid 2>/dev/null");
    }
    @unlink($pidFile);
}

// Reset all per-session files
@unlink("$dir/$user.stop");
file_put_contents("$dir/$user.hb", (string) time());
file_put_contents("$dir/$user.json", json_encode([
    'state'     => 'running',
    'text'      => 'Starting...',
    'interface' => '-',
    'down'      => 0,
    'up'        => 0,
    'remaining' => 180,
    'updated'   => time(),
    'history'   => [],
]));

// Launch the monitor in the background
exec(sprintf(
    'nohup python3 %s %s > %s 2>&1 &',
    escapeshellarg($monitor),
    escapeshellarg($user),
    escapeshellarg("$dir/$user.log")
));

echo json_encode(['ok' => true]);
```

---

### 7.3 `/var/www/html/traffic/stop.php`

```php
<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
// TODO: add the Zalpro admin session check here (see Section 11).
// Accepts GET (manual button) and POST (navigator.sendBeacon on page close).

$user = trim($_GET['username'] ?? $_POST['username'] ?? '');
if (!preg_match('/^[\w.@-]{1,64}$/', $user)) {
    echo json_encode(['ok' => false, 'error' => 'Invalid username']);
    exit;
}

file_put_contents("/var/lib/netpoint-traffic/data/$user.stop", '1');
echo json_encode(['ok' => true]);
```

---

### 7.4 `/var/www/html/traffic/heartbeat.php`

```php
<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
// TODO: add the Zalpro admin session check here (see Section 11).

$user = trim($_GET['username'] ?? '');
if (!preg_match('/^[\w.@-]{1,64}$/', $user)) {
    echo json_encode(['ok' => false]);
    exit;
}

touch("/var/lib/netpoint-traffic/data/$user.hb");
echo json_encode(['ok' => true]);
```

---

### 7.5 `/var/www/html/traffic/status.php`

```php
<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
// TODO: add the Zalpro admin session check here (see Section 11).

$user = trim($_GET['username'] ?? '');
if (!preg_match('/^[\w.@-]{1,64}$/', $user)) {
    echo json_encode(['state' => 'error', 'text' => 'Invalid username']);
    exit;
}

$file = "/var/lib/netpoint-traffic/data/$user.json";
if (!file_exists($file)) {
    echo json_encode(['state' => 'idle', 'text' => 'Idle']);
    exit;
}

$state = json_decode(file_get_contents($file), true) ?: [];

// If the monitor has not updated for 20 seconds while "running", treat it as failed
if (($state['state'] ?? '') === 'running' && time() - ($state['updated'] ?? 0) > 20) {
    $state['state']    = 'error';
    $state['text']     = 'Monitor not responding';
    $state['down']     = 0;
    $state['up']       = 0;
}

echo json_encode($state);
```

---

### 7.6 `/var/www/html/traffic/panel.php`

```php
<?php $trafficUser = trim($user->username ?? ''); ?>
<style>
  .tm-card { background:#0f172a; color:#e2e8f0; border-radius:12px; padding:20px; margin-top:16px; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; }
  .tm-head { display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; }
  .tm-title { font-size:15px; font-weight:600; letter-spacing:.2px; }
  .tm-pill { font-size:12px; padding:4px 10px; border-radius:999px; background:#1e293b; color:#94a3b8; display:flex; gap:7px; align-items:center; }
  .tm-dot { width:8px; height:8px; border-radius:50%; background:#64748b; }
  .tm-pill.live { color:#86efac; }
  .tm-pill.live .tm-dot { background:#22c55e; box-shadow:0 0 0 4px rgba(34,197,94,.18); }
  .tm-pill.wait { color:#fcd34d; }
  .tm-pill.wait .tm-dot { background:#f59e0b; animation:tmPulse 1.2s infinite; }
  .tm-pill.err { color:#fca5a5; }
  .tm-pill.err .tm-dot { background:#ef4444; }
  @keyframes tmPulse { 50% { opacity:.25; } }
  .tm-metrics { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .tm-metric { background:#111c31; border:1px solid #1e2d47; border-radius:10px; padding:14px 16px; }
  .tm-label { font-size:11px; text-transform:uppercase; letter-spacing:.08em; color:#64748b; }
  .tm-value { font-size:28px; font-weight:600; margin-top:6px; font-variant-numeric:tabular-nums; white-space:nowrap; }
  .tm-value small { font-size:13px; font-weight:500; color:#94a3b8; margin-left:4px; }
  .tm-down .tm-value { color:#38bdf8; }
  .tm-up .tm-value { color:#fbbf24; }
  .tm-meta { display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap; margin:16px 0 8px; font-size:12px; color:#94a3b8; }
  .tm-meta b { color:#e2e8f0; font-weight:500; font-variant-numeric:tabular-nums; }
  .tm-bar { height:3px; background:#1e293b; border-radius:2px; overflow:hidden; }
  .tm-bar > div { height:100%; width:0; background:#38bdf8; transition:width .9s linear; }
  .tm-chart-head { display:flex; justify-content:space-between; font-size:11px; color:#64748b; margin-top:16px; }
  .tm-chart { width:100%; height:170px; display:block; margin-top:6px; }
  .tm-actions { display:flex; gap:10px; margin-top:16px; }
  .tm-btn { flex:1; padding:10px 0; border-radius:8px; font-size:14px; font-weight:600; cursor:pointer; border:1px solid transparent; }
  .tm-btn:disabled { opacity:.35; cursor:not-allowed; }
  .tm-start { background:#2563eb; color:#fff; }
  .tm-start:hover:not(:disabled) { background:#1d4ed8; }
  .tm-stop { background:transparent; color:#f87171; border-color:#7f1d1d; }
  .tm-stop:hover:not(:disabled) { background:#2a1215; }
  .tm-note { font-size:11px; color:#475569; margin-top:12px; }
</style>

<div class="tm-card" id="tmCard">
  <div class="tm-head">
    <div class="tm-title">Live Traffic</div>
    <div class="tm-pill" id="tmPill"><span class="tm-dot"></span><span id="tmPillText">Idle</span></div>
  </div>

  <div class="tm-metrics">
    <div class="tm-metric tm-down">
      <div class="tm-label">Download</div>
      <div class="tm-value" id="tmDown">0<small>bps</small></div>
    </div>
    <div class="tm-metric tm-up">
      <div class="tm-label">Upload</div>
      <div class="tm-value" id="tmUp">0<small>bps</small></div>
    </div>
  </div>

  <div class="tm-meta">
    <span>Interface <b id="tmIface">-</b></span>
    <span>Auto-stop in <b id="tmLeft">03:00</b></span>
  </div>
  <div class="tm-bar"><div id="tmBar"></div></div>

  <div class="tm-chart-head">
    <span>Last 60 seconds</span>
    <span id="tmPeak"></span>
  </div>
  <canvas id="tmChart" class="tm-chart"></canvas>

  <div class="tm-actions">
    <button id="tmStart" class="tm-btn tm-start">Start monitoring</button>
    <button id="tmStop" class="tm-btn tm-stop" disabled>Stop</button>
  </div>
  <div class="tm-note">The monitor runs only while this page is open. It stops automatically when you refresh or close the page.</div>
</div>

<script>
(function () {
  const USER = <?= json_encode($trafficUser) ?>;
  const AUTO = 180;
  const $ = id => document.getElementById(id);
  const URL = {
    status: "/traffic/status.php?username=",
    start:  "/traffic/start.php?username=",
    stop:   "/traffic/stop.php?username=",
    hb:     "/traffic/heartbeat.php?username="
  };
  const enc = encodeURIComponent(USER);

  let running = false;
  let hist = [];          // Array of [download_bps, upload_bps] from the server
  let pollTimer = null;
  let hbTimer = null;

  // Display only: converts bits per second to a readable unit (1000 steps)
  function fmt(bps) {
    if (bps < 1e3) return [bps.toFixed(0), "bps"];
    if (bps < 1e6) return [(bps / 1e3).toFixed(2), "Kbps"];
    if (bps < 1e9) return [(bps / 1e6).toFixed(2), "Mbps"];
    return [(bps / 1e9).toFixed(2), "Gbps"];
  }

  function setValue(id, bps) {
    const [value, unit] = fmt(bps || 0);
    $(id).innerHTML = value + "<small>" + unit + "</small>";
  }

  function setPill(kind, text) {
    $("tmPill").className = "tm-pill" + (kind ? " " + kind : "");
    $("tmPillText").textContent = text;
  }

  function setControls(on) {
    running = on;
    $("tmStart").disabled = on;
    $("tmStop").disabled = !on;
  }

  function setTimer(seconds) {
    const s = Math.max(0, seconds || 0);
    $("tmLeft").textContent = String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
    $("tmBar").style.width = (s / AUTO * 100) + "%";
  }

  function draw() {
    const canvas = $("tmChart");
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    }
    const g = canvas.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);

    const top = 8, bottom = h - 4;
    g.strokeStyle = "#1e293b";
    g.lineWidth = 1;
    for (let i = 0; i <= 3; i++) {
      const y = top + (bottom - top) * i / 3;
      g.beginPath(); g.moveTo(0, y + 0.5); g.lineTo(w, y + 0.5); g.stroke();
    }

    const peak = Math.max(1, ...hist.map(p => Math.max(p[0], p[1])));
    $("tmPeak").textContent = hist.length ? "Peak " + fmt(peak).join(" ") : "";

    if (hist.length < 2) {
      g.fillStyle = "#475569";
      g.font = "12px system-ui";
      g.textAlign = "center";
      g.fillText(running ? "Waiting for data..." : "Press Start to begin the graph", w / 2, h / 2);
      return;
    }

    const step = w / 59;
    const point = (i, idx) => [
      w - (hist.length - 1 - i) * step,
      bottom - (bottom - top) * (hist[i][idx] / peak)
    ];

    // Download area fill
    const gradient = g.createLinearGradient(0, top, 0, bottom);
    gradient.addColorStop(0, "rgba(56,189,248,0.35)");
    gradient.addColorStop(1, "rgba(56,189,248,0)");
    g.beginPath();
    hist.forEach((_, i) => {
      const [x, y] = point(i, 0);
      if (i) { g.lineTo(x, y); } else { g.moveTo(x, y); }
    });
    const lastX = point(hist.length - 1, 0)[0];
    const firstX = point(0, 0)[0];
    g.lineTo(lastX, bottom);
    g.lineTo(firstX, bottom);
    g.closePath();
    g.fillStyle = gradient;
    g.fill();

    // Download and upload lines
    [[0, "#38bdf8"], [1, "#fbbf24"]].forEach(([idx, color]) => {
      g.beginPath();
      g.strokeStyle = color;
      g.lineWidth = 1.8;
      g.lineJoin = "round";
      hist.forEach((_, i) => {
        const [x, y] = point(i, idx);
        if (i) { g.lineTo(x, y); } else { g.moveTo(x, y); }
      });
      g.stroke();
    });
  }

  function render(state) {
    const iface = state.interface && state.interface !== "-" ? state.interface : "Resolving...";
    $("tmIface").textContent = iface;
    setValue("tmDown", state.down);
    setValue("tmUp", state.up);
    setTimer(state.remaining);
    hist = state.history || [];
    draw();

    if (state.state === "error") {
      setPill("err", state.text || "Error");
    } else if (state.text === "Live") {
      setPill("live", "Live");
    } else {
      setPill("wait", state.text || "Connecting...");
    }
  }

  function resetUI(text) {
    hist = [];
    $("tmIface").textContent = "-";
    setValue("tmDown", 0);
    setValue("tmUp", 0);
    setTimer(AUTO);
    setPill("", text || "Idle");
    draw();
  }

  function sendHeartbeat() {
    fetch(URL.hb + enc, { cache: "no-store" }).catch(() => {});
  }

  function stopHeartbeat() {
    if (hbTimer) {
      clearInterval(hbTimer);
      hbTimer = null;
    }
  }

  async function poll() {
    pollTimer = null;
    if (!running) return;
    try {
      const state = await (await fetch(URL.status + enc, { cache: "no-store" })).json();
      render(state);
      if (state.state === "running") {
        pollTimer = setTimeout(poll, 1000);
      } else {
        finish(state.state === "error");
      }
    } catch (e) {
      setPill("wait", "Reconnecting...");
      pollTimer = setTimeout(poll, 2000);
    }
  }

  function finish(isError) {
    setControls(false);
    stopHeartbeat();
    if (pollTimer) {
      clearTimeout(pollTimer);
      pollTimer = null;
    }
    if (!isError) setPill("", "Stopped");
  }

  async function startMonitor() {
    if (running) return;
    setControls(true);
    resetUI("Resolving interface...");
    try {
      const result = await (await fetch(URL.start + enc, { cache: "no-store" })).json();
      if (!result.ok) {
        setPill("err", result.error || "Start failed");
        setControls(false);
        return;
      }
    } catch (e) {
      setPill("err", "Start request failed");
      setControls(false);
      return;
    }
    sendHeartbeat();
    hbTimer = setInterval(sendHeartbeat, 5000);
    poll();
  }

  function stopMonitor() {
    if (!running) return;
    stopHeartbeat();
    if (pollTimer) {
      clearTimeout(pollTimer);
      pollTimer = null;
    }
    setControls(false);
    setPill("", "Stopping...");
    fetch(URL.stop + enc, { cache: "no-store" })
      .then(() => setPill("", "Stopped"))
      .catch(() => setPill("err", "Stop request failed"));
  }

  // Page refresh, navigation, or tab close: stop the monitor immediately
  window.addEventListener("pagehide", () => {
    if (running && navigator.sendBeacon) {
      navigator.sendBeacon(URL.stop + enc);
    }
  });

  // Page load: stop any monitor left running from an earlier session, then start from Idle
  (async () => {
    resetUI("Idle");
    try {
      const state = await (await fetch(URL.status + enc, { cache: "no-store" })).json();
      if (state.state === "running") {
        await fetch(URL.stop + enc, { cache: "no-store" });
      }
    } catch (e) {
      // Ignore; the panel still works without this check
    }
  })();

  $("tmStart").onclick = startMonitor;
  $("tmStop").onclick = stopMonitor;
  window.addEventListener("resize", draw);
})();
</script>
```

---

## 8. Verification and Testing

### 8.1 Command-line tests (on the Zalpro server)

Replace `TESTUSER` with an active PPPoE username.

**Test the monitor directly:**

```bash
sudo -u www-data python3 /opt/netpoint-traffic/monitor.py TESTUSER
```

Let it run for 10 to 15 seconds, then press `Ctrl+C`. The output should show no tracebacks in normal operation. In another terminal:

```bash
sudo cat /var/lib/netpoint-traffic/data/TESTUSER.json
```

Expected: `"state": "running"`, `"text": "Live"`, and a `pp0.X` interface with non-zero `down` and `up` values.

**Test the web endpoints:**

```bash
curl "http://127.0.0.1/traffic/start.php?username=TESTUSER"
sleep 8
curl "http://127.0.0.1/traffic/heartbeat.php?username=TESTUSER"
curl "http://127.0.0.1/traffic/status.php?username=TESTUSER"
curl "http://127.0.0.1/traffic/stop.php?username=TESTUSER"
sleep 3
curl "http://127.0.0.1/traffic/status.php?username=TESTUSER"
```

Expected sequence:

1. `start.php` returns `{"ok":true}`.
2. After about 8 seconds, `status.php` returns `"text":"Live"` with interface and rates.
3. After `stop.php`, `status.php` returns `"state":"stopped"`.

### 8.2 Browser tests

1. Open a user profile and press **Ctrl+F5**. The panel should show **Idle**.
2. Click **Start monitoring**. The status should change to **Resolving interface...**, then **Reading live traffic...**, then **Live**. The interface name and rates should appear.
3. Watch the graph fill in over several seconds.
4. Refresh the page. The monitor should stop, and the panel should return to **Idle**.
5. Start again, then close the tab. Check on the server:
   ```bash
   ps aux | grep monitor.py | grep -v grep
   ```
   The process should disappear within a few seconds.
6. Start again, then click **Stop**. The status should change to **Stopped**, and the interface should show `-`.
7. Start and leave the page open for 3 minutes. The monitor should stop automatically with the message **Auto-stopped after 3 minutes**.
8. Start for an offline user. The status should show **Subscriber offline, retrying...** and the interface should show `-`.

---

## 9. Operating the Monitor

### 9.1 Normal use

1. Open the subscriber's profile page.
2. Click **Start monitoring**.
3. Read the Download and Upload values, the interface name, and the graph.
4. Click **Stop** when finished, or simply navigate away.

### 9.2 Behavior summary

| Action | Result |
|---|---|
| Start monitoring | Fresh `pp0.X` lookup, new session, empty graph |
| Refresh page | Monitor stops, panel shows Idle |
| Close tab or browser | Monitor stops within about 20 seconds (immediately with `pagehide`) |
| Click Stop | Monitor stops, panel shows Stopped |
| 3 minutes elapsed | Monitor auto-stops |
| Subscriber goes offline | Monitor keeps retrying until the subscriber returns, the admin stops it, or the time limit is reached |
| Start again for same user | Old monitor is killed, new interface lookup runs |

### 9.3 Useful server commands

```bash
# Running monitors
ps aux | grep monitor.py | grep -v grep

# Current state for a user
cat /var/lib/netpoint-traffic/data/USERNAME.json

# Monitor log for a user
cat /var/lib/netpoint-traffic/data/USERNAME.log

# Stop all monitors manually
sudo pkill -f monitor.py
sudo rm -f /var/lib/netpoint-traffic/data/*.stop /var/lib/netpoint-traffic/data/*.hb /var/lib/netpoint-traffic/data/*.pid
```

---

## 10. Troubleshooting

### 10.1 "Invalid username" in the panel

**Cause:** `$user->username` is empty or not set in the profile page context.

**Fix:**
- Check the first line of `/var/www/html/traffic/panel.php`.
- Confirm the variable name used in `profile.php` for the username, for example:
  ```bash
  grep -n "username" /var/www/html/application/views/themes/legacy/admin_portal/users/profile.php | head
  ```
- Update the first line of `panel.php` to match, for example `<?php $trafficUser = trim($customer->username ?? ''); ?>`.

### 10.2 "Monitor not responding" after a few seconds

**Cause:** The monitor process stopped or crashed.

**Fix:**
```bash
cat /var/lib/netpoint-traffic/data/USERNAME.log
```

Common causes:
- SSH authentication failure (wrong password or user).
- The router refused the connection (source IP not allowed, or port blocked).
- A Python package is missing for `www-data`.

### 10.3 "Subscriber offline, retrying..." for an active user

**Cause:** The `show subscribers user-name` output does not contain a `pp0.X` interface, or the username is wrong.

**Fix:**
1. Verify the exact username on the router:
   ```bash
   sudo -u www-data ssh -p 8877 -o StrictHostKeyChecking=no hanxill@103.170.179.40 "show subscribers"
   ```
2. Compare the username with the one in the profile page.

### 10.4 Start button does nothing or shows "Start request failed"

**Cause:** PHP `exec()` is disabled, or `start.php` has a syntax error.

**Fix:**
```bash
php -r 'echo function_exists("exec") ? "exec OK\n" : "exec DISABLED\n";'
php -l /var/www/html/traffic/start.php
```

If `exec` is disabled, check `disable_functions` in `php.ini`.

### 10.5 Old interface or old graph appears after refresh

**Cause:** Stale state file.

**Fix:**
```bash
sudo rm -f /var/lib/netpoint-traffic/data/USERNAME.json
```
Then refresh the page with **Ctrl+F5**. The panel also resets state on every page load, so this should only be needed after manual tests.

### 10.6 Monitor keeps running after the page is closed

**Cause:** Heartbeat file is not being updated, or the browser blocked `sendBeacon`.

**Fix:**
- Check that `heartbeat.php` is reachable:
  ```bash
  curl "http://127.0.0.1/traffic/heartbeat.php?username=USERNAME"
  ```
- Check the heartbeat file time:
  ```bash
  ls -l /var/lib/netpoint-traffic/data/USERNAME.hb
  ```
- If it is not updating, check browser console errors (F12).

### 10.7 Permission errors in the log

```bash
ls -l /opt/netpoint-traffic/monitor.py
ls -ld /var/lib/netpoint-traffic/data
```

Expected:
- `monitor.py` readable by `www-data` (mode `640`, group `www-data`).
- `data` directory owned by `www-data`.

### 10.8 Python import errors

```bash
sudo -u www-data python3 -c "import paramiko, pyte; print('OK')"
```

If this fails, install the packages again:

```bash
sudo pip3 install paramiko pyte
```

---

## 11. Security Recommendations

These items are required for production use.

1. **Add an admin authentication check** to `start.php`, `stop.php`, `heartbeat.php`, and `status.php`. Without this, anyone who can reach these URLs can start SSH sessions to the router. Use the same session check that protects the profile page. Example:
   ```php
   session_start();
   if (empty($_SESSION['admin_id'])) {
       http_response_code(403);
       echo json_encode(['ok' => false, 'error' => 'Unauthorized']);
       exit;
   }
   ```
   Replace `admin_id` with the session key that Zalpro uses.

2. **Rotate the Juniper password.** The password `hanxill` was shared in plain text during setup. Change it on the router.

3. **Use a limited-permission Juniper account.** Create a dedicated user, for example:
   ```
   configure
   set system login user netpoint-monitor class operator
   set system login user netpoint-monitor authentication plain-text-password
   commit
   ```
   Test that this user can run `show subscribers` and `monitor interface`. Adjust the login class if needed.

4. **Protect the password in `monitor.py`.** Keep the file mode at `640` with root ownership and `www-data` group. Do not place it inside the web root. For stronger protection, read `SSH_PASS` from an environment variable or a root-only file.

5. **Use HTTPS** for the Zalpro admin area. Stop and heartbeat requests carry session cookies.

6. **Keep the SSH host key policy in mind.** The script uses `AutoAddPolicy`, which accepts any host key. For production, pin the router's host key in `known_hosts` and switch to `RejectPolicy`.

---

## 12. Configuration Reference

| Setting | File | Default | Purpose |
|---|---|---|---|
| `ROUTER_IP` | `monitor.py` | `103.170.179.40` | Juniper MX104 management IP |
| `SSH_PORT` | `monitor.py` | `8877` | Juniper SSH port |
| `SSH_USER` | `monitor.py` | `hanxill` | Juniper login user (use a limited user) |
| `SSH_PASS` | `monitor.py` | `CHANGE_ME` | Juniper login password |
| `AUTO_STOP` | `monitor.py` | `180` | Maximum session length in seconds |
| `HB_TIMEOUT` | `monitor.py` | `20` | Stop if no heartbeat for this many seconds |
| `DATA` | `monitor.py` | `/var/lib/netpoint-traffic/data` | Runtime data directory |
| `HISTORY_LEN` | `monitor.py` | `60` | Samples kept for the graph |
| `$trafficUser` | `panel.php` (line 1) | `$user->username` | Username source from the profile page |
| Heartbeat interval | `panel.php` | `5000` ms | Browser keep-alive interval |
| Status poll interval | `panel.php` | `1000` ms | Browser refresh interval |
| Stale monitor threshold | `status.php` | `20` s | Mark monitor as failed after this delay |

**Change the auto-stop duration** in both `monitor.py` (`AUTO_STOP`) and `panel.php` (`const AUTO = 180;`) and `start.php` (`'remaining' => 180`).

---

## 13. Known Limitations

- **Average rate, not instant peak.** The `(N bps)` value is the router's average over its own interval. Short bursts are smoothed.
- **Screen parsing.** The regular expressions depend on the Junos `monitor interface` output format. A major Junos upgrade may require updating `IN_RE` and `OUT_RE` in `monitor.py`.
- **One monitor per user.** If two administrators view the same subscriber, starting the monitor from the second session stops the first session's monitor.
- **Background tabs.** Browsers throttle timers in background tabs. If the tab is inactive for longer than the heartbeat timeout, the monitor stops. Increase `HB_TIMEOUT` if this is a problem.
- **Python 3.6 on the server.** The code uses only features available in Python 3.6. Upgrading Python is recommended for long-term support of `paramiko`.
- **Login required.** The endpoints do not include authentication until you add the check described in Section 11.

---

*End of document.*

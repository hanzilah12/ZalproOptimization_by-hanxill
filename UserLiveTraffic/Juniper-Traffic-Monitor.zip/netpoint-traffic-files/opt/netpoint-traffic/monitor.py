#!/usr/bin/env python3
"""
NetPoint Live Traffic Monitor - Juniper MX104 SSH monitor.

Usage:
    monitor.py <pppoe_username>

Resolves the subscriber's active pp0.X logical interface on each start,
runs 'monitor interface' on the router, parses the bps values from the
terminal output, and writes the state to a JSON file that the web panel reads.
The process stops on stop flag, stale heartbeat, auto-stop timeout, or error.
"""
import json
import os
import re
import socket
import sys
import time

import paramiko
import pyte

# ---------------------------------------------------------------
# CONFIGURATION - set these values before deployment
# ---------------------------------------------------------------
ROUTER_IP = "103.170.179.40"
SSH_PORT = 8877
SSH_USER = "hanxill"              # Recommended: a dedicated, limited-permission user
SSH_PASS = "CHANGE_ME"            # Set the real password here
AUTO_STOP = 180                   # Maximum monitoring duration in seconds
HB_TIMEOUT = 20                   # Stop if no browser heartbeat for this many seconds
DATA = "/var/lib/netpoint-traffic/data"
HISTORY_LEN = 60                  # Number of samples kept for the graph
# ---------------------------------------------------------------

COLS, ROWS = 120, 40
PROMPT = re.compile(r"\S+@\S+[>#] \Z")
IN_RE = re.compile(r"Input\s+bytes:\s*\d+\s*\(\s*(\d+)\s*bps\s*\)")
OUT_RE = re.compile(r"Output\s+bytes:\s*\d+\s*\(\s*(\d+)\s*bps\s*\)")
SEC_RE = re.compile(r"Seconds:\s*(\d+)")
ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b[()][A-Za-z0-9]|\r")


class Shell:
    """Interactive SSH shell helper for Junos CLI commands."""

    def __init__(self, host, user, password, port):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.client.connect(
            host,
            port=port,
            username=user,
            password=password,
            timeout=8,
            look_for_keys=False,
            allow_agent=False,
        )
        self.channel = self.client.invoke_shell(width=1000, height=1000)
        self.channel.settimeout(0.2)
        self._read(8)
        self.run("set cli screen-length 0")
        self.run("set cli screen-width 1000")

    def _read(self, timeout):
        """Read until the CLI prompt appears or the timeout expires."""
        buf, end = "", time.monotonic() + timeout
        while time.monotonic() < end:
            try:
                data = self.channel.recv(65535)
                if not data:
                    raise ConnectionError("SSH session closed")
                buf += data.decode(errors="replace")
            except socket.timeout:
                pass
            if PROMPT.search(buf):
                return buf
        raise TimeoutError("Router did not answer in time")

    def run(self, command, timeout=6):
        self.channel.send(command + "\n")
        return self._read(timeout)

    def close(self):
        try:
            self.client.close()
        except Exception:
            pass


def write_status(user, state):
    """Atomically write the state file so the web panel never reads a partial file."""
    path = os.path.join(DATA, user + ".json")
    tmp = path + ".tmp"
    with open(tmp, "w") as handle:
        json.dump(state, handle)
    os.replace(tmp, path)


def remove_quiet(path):
    try:
        os.remove(path)
    except OSError:
        pass


def main():
    user = sys.argv[1]
    stop_file = os.path.join(DATA, user + ".stop")
    hb_file = os.path.join(DATA, user + ".hb")
    pid_file = os.path.join(DATA, user + ".pid")
    deadline = time.monotonic() + AUTO_STOP
    reason = {"text": "Stopped"}

    with open(pid_file, "w") as handle:
        handle.write(str(os.getpid()))

    state = {
        "state": "running",
        "text": "Connecting...",
        "interface": "-",
        "down": 0,
        "up": 0,
        "remaining": AUTO_STOP,
        "updated": time.time(),
        "history": [],
    }

    def save(**fields):
        state.update(fields)
        state["remaining"] = max(0, int(deadline - time.monotonic()))
        state["updated"] = time.time()
        write_status(user, state)

    def should_stop():
        if os.path.exists(stop_file):
            reason["text"] = "Stopped"
            return True
        if time.monotonic() >= deadline:
            reason["text"] = "Auto-stopped after 3 minutes"
            return True
        try:
            if time.time() - os.path.getmtime(hb_file) > HB_TIMEOUT:
                reason["text"] = "Page closed or refreshed, monitor stopped"
                return True
        except OSError:
            reason["text"] = "Stopped"
            return True
        return False

    shell = None
    try:
        save()
        shell = Shell(ROUTER_IP, SSH_USER, SSH_PASS, SSH_PORT)

        while not should_stop():
            # Fresh interface lookup on every iteration
            output = shell.run("show subscribers user-name %s" % user)
            match = re.search(r"\b(pp0\.\d+)\b", output)
            if not match:
                save(text="Subscriber offline, retrying...", interface="-", down=0, up=0)
                time.sleep(2)
                continue

            ifl = match.group(1)
            save(text="Reading live traffic...", interface=ifl)

            shell.channel.resize_pty(width=COLS, height=ROWS)
            screen = pyte.Screen(COLS, ROWS)
            stream = pyte.Stream(screen)
            shell.channel.send("monitor interface %s\n" % ifl)

            last_update = time.monotonic()
            last_sec, tail = None, ""

            while not should_stop():
                try:
                    data = shell.channel.recv(65535)
                    if not data:
                        raise ConnectionError("SSH session closed")
                    chunk = data.decode(errors="replace")
                    stream.feed(chunk)
                    tail = (tail + ANSI.sub("", chunk))[-300:]
                except socket.timeout:
                    pass

                text = "\n".join(screen.display)
                now = time.monotonic()
                match_in = IN_RE.search(text)
                match_out = OUT_RE.search(text)

                if match_in and match_out:
                    sec_match = SEC_RE.search(text)
                    sec = sec_match.group(1) if sec_match else None
                    if sec is not None:
                        fresh = sec != last_sec
                    else:
                        fresh = now - last_update >= 1.0

                    if fresh and now - last_update >= 0.3:
                        last_update, last_sec = now, sec
                        down = int(match_out.group(1))   # Output = subscriber download
                        up = int(match_in.group(1))      # Input  = subscriber upload
                        history = state["history"]
                        history.append([down, up])
                        del history[:-HISTORY_LEN]
                        save(text="Live", down=down, up=up, interface=ifl)

                # Prompt returned or no data for 6 seconds: resolve the interface again
                if PROMPT.search(tail) or now - last_update > 6:
                    break

            try:
                shell.channel.send("q")
                shell._read(4)
            except Exception:
                pass

        save(state="stopped", text=reason["text"], interface="-",
             down=0, up=0, history=[])

    except Exception as exc:
        save(state="error", text="Error: %s" % exc, interface="-",
             down=0, up=0, history=[])

    finally:
        if shell:
            shell.close()
        remove_quiet(stop_file)
        remove_quiet(hb_file)
        try:
            with open(pid_file) as handle:
                if handle.read().strip() == str(os.getpid()):
                    remove_quiet(pid_file)
        except OSError:
            pass


if __name__ == "__main__":
    main()
